"""
analise.py
==========
Análise de dados ambientais do Pantanal (Jan/2025).

Etapas:
  1. Leitura e tratamento dos dados (interpolação linear para valores ausentes)
  2. Geração de estatísticas básicas
  3. Exportação de dados tratados para JSON (consumido pelo frontend)
  4. Geração de dois gráficos estáticos com Matplotlib
"""

import json
import os
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.gridspec import GridSpec

# ─── Configuração ────────────────────────────────────────────────────────────
DATA_FILE   = "dados_pantanal.csv"
OUTPUT_DIR  = "output"
JSON_FILE   = os.path.join(OUTPUT_DIR, "dados_tratados.json")
CHART1_FILE = os.path.join(OUTPUT_DIR, "temperatura_ndvi.png")
CHART2_FILE = os.path.join(OUTPUT_DIR, "nivel_rio.png")

os.makedirs(OUTPUT_DIR, exist_ok=True)

# ─── 1. Leitura dos dados ─────────────────────────────────────────────────────
print("📥 Lendo dados...")
df = pd.read_csv(DATA_FILE, parse_dates=["data"])
df = df.sort_values("data").reset_index(drop=True)

print(f"\n📋 Dados brutos ({len(df)} registros):")
print(df.to_string(index=False))

# ─── 2. Tratamento de valores ausentes ───────────────────────────────────────
print("\n🔍 Valores ausentes antes do tratamento:")
print(df.isnull().sum())

# Interpolação linear: adequada para séries temporais contínuas como
# temperatura, nível de rio e índice de vegetação.
df["nivel_rio_m"] = df["nivel_rio_m"].interpolate(method="linear")
df["ndvi"]        = df["ndvi"].interpolate(method="linear")

print("\n✅ Valores ausentes após tratamento:")
print(df.isnull().sum())

print(f"\n📋 Dados tratados:")
print(df.to_string(index=False))

# ─── 3. Estatísticas básicas ──────────────────────────────────────────────────
stats = {
    "temperatura_c": {
        "media":  round(df["temperatura_c"].mean(), 2),
        "min":    round(df["temperatura_c"].min(),  2),
        "max":    round(df["temperatura_c"].max(),  2),
        "desvio": round(df["temperatura_c"].std(),  2),
    },
    "nivel_rio_m": {
        "media":  round(df["nivel_rio_m"].mean(), 2),
        "min":    round(df["nivel_rio_m"].min(),  2),
        "max":    round(df["nivel_rio_m"].max(),  2),
        "desvio": round(df["nivel_rio_m"].std(),  2),
    },
    "ndvi": {
        "media":  round(df["ndvi"].mean(), 4),
        "min":    round(df["ndvi"].min(),  4),
        "max":    round(df["ndvi"].max(),  4),
        "desvio": round(df["ndvi"].std(),  4),
    },
}

print("\n📊 Estatísticas básicas:")
for variavel, vals in stats.items():
    print(f"\n  {variavel.upper()}")
    for k, v in vals.items():
        print(f"    {k:8s}: {v}")

# ─── 4. Exporta JSON para o frontend ─────────────────────────────────────────
export = {
    "registros": [
        {
            "data":          row.data.strftime("%Y-%m-%d"),
            "temperatura_c": round(row.temperatura_c, 2),
            "nivel_rio_m":   round(row.nivel_rio_m,   2),
            "ndvi":          round(row.ndvi,           4),
        }
        for row in df.itertuples()
    ],
    "estatisticas": stats,
}

with open(JSON_FILE, "w", encoding="utf-8") as f:
    json.dump(export, f, ensure_ascii=False, indent=2)

print(f"\n💾 JSON exportado → {JSON_FILE}")

# ─── 5. Gráficos Matplotlib ───────────────────────────────────────────────────
PALETTE = {
    "temp":   "#E07B39",
    "ndvi":   "#4CAF50",
    "rio":    "#2196F3",
    "bg":     "#0F1A14",
    "panel":  "#162010",
    "grid":   "#2A3B2A",
    "text":   "#D4E8C2",
    "accent": "#8BC34A",
}

plt.rcParams.update({
    "figure.facecolor":  PALETTE["bg"],
    "axes.facecolor":    PALETTE["panel"],
    "axes.edgecolor":    PALETTE["grid"],
    "axes.labelcolor":   PALETTE["text"],
    "xtick.color":       PALETTE["text"],
    "ytick.color":       PALETTE["text"],
    "grid.color":        PALETTE["grid"],
    "text.color":        PALETTE["text"],
    "font.family":       "monospace",
})

datas = df["data"]

# ── Gráfico 1: Temperatura + NDVI (duplo eixo Y) ─────────────────────────────
fig, ax1 = plt.subplots(figsize=(11, 5))
fig.suptitle("Temperatura & NDVI — Pantanal Jan/2025",
             fontsize=14, fontweight="bold", color=PALETTE["accent"], y=1.01)

ax1.plot(datas, df["temperatura_c"],
         color=PALETTE["temp"], linewidth=2.2, marker="o", markersize=5,
         label="Temperatura (°C)")
ax1.fill_between(datas, df["temperatura_c"],
                 alpha=0.15, color=PALETTE["temp"])
ax1.set_ylabel("Temperatura (°C)", color=PALETTE["temp"], fontsize=11)
ax1.tick_params(axis="y", labelcolor=PALETTE["temp"])
ax1.xaxis.set_major_formatter(mdates.DateFormatter("%d/%m"))
ax1.xaxis.set_major_locator(mdates.DayLocator())
plt.setp(ax1.xaxis.get_majorticklabels(), rotation=45, ha="right")
ax1.grid(True, linestyle="--", alpha=0.4)

ax2 = ax1.twinx()
ax2.plot(datas, df["ndvi"],
         color=PALETTE["ndvi"], linewidth=2.2, marker="s", markersize=5,
         linestyle="--", label="NDVI")
ax2.fill_between(datas, df["ndvi"],
                 alpha=0.12, color=PALETTE["ndvi"])
ax2.set_ylabel("NDVI", color=PALETTE["ndvi"], fontsize=11)
ax2.tick_params(axis="y", labelcolor=PALETTE["ndvi"])
ax2.set_facecolor(PALETTE["panel"])

# Legenda unificada
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2,
           loc="lower right", framealpha=0.3,
           facecolor=PALETTE["panel"], edgecolor=PALETTE["grid"])

fig.tight_layout()
fig.savefig(CHART1_FILE, dpi=150, bbox_inches="tight",
            facecolor=PALETTE["bg"])
plt.close(fig)
print(f"🖼️  Gráfico 1 salvo → {CHART1_FILE}")

# ── Gráfico 2: Nível do Rio (área + barras de média) ─────────────────────────
fig, ax = plt.subplots(figsize=(11, 5))
fig.suptitle("Nível do Rio — Pantanal Jan/2025",
             fontsize=14, fontweight="bold", color=PALETTE["accent"], y=1.01)

media_rio = df["nivel_rio_m"].mean()

ax.fill_between(datas, df["nivel_rio_m"],
                alpha=0.35, color=PALETTE["rio"])
ax.plot(datas, df["nivel_rio_m"],
        color=PALETTE["rio"], linewidth=2.5, marker="D", markersize=6)
ax.axhline(media_rio, color="#FF9800", linewidth=1.5,
           linestyle=":", label=f"Média: {media_rio:.2f} m")

# Anotação dos valores nos pontos
for x, y in zip(datas, df["nivel_rio_m"]):
    ax.annotate(f"{y:.1f}",
                xy=(x, y), xytext=(0, 8),
                textcoords="offset points",
                ha="center", fontsize=8, color=PALETTE["text"])

ax.set_ylabel("Nível do Rio (m)", fontsize=11)
ax.xaxis.set_major_formatter(mdates.DateFormatter("%d/%m"))
ax.xaxis.set_major_locator(mdates.DayLocator())
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha="right")
ax.grid(True, linestyle="--", alpha=0.4)
ax.legend(framealpha=0.3, facecolor=PALETTE["panel"],
          edgecolor=PALETTE["grid"])

fig.tight_layout()
fig.savefig(CHART2_FILE, dpi=150, bbox_inches="tight",
            facecolor=PALETTE["bg"])
plt.close(fig)
print(f"🖼️  Gráfico 2 salvo → {CHART2_FILE}")

print("\n✅ Análise concluída. Abra output/index.html para ver o dashboard interativo.")
